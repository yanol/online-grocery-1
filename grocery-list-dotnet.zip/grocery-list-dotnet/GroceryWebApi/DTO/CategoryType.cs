namespace GroceryWebApi.DTO
{
    public class CategoryType
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}